
import jahuwaldt.plot.PlotWindow;

/**
*  A simple class for testing my plotting package.
*  See the source code for jahuwaldt.plot.PlotWindow for
*  examples of how to set up and modify plots.
**/
public class PlotTester {

    public static void main(String args[]) {
	
		//	Simply call the testing code contained in the PlotWindow class.
        PlotWindow.main(null);
    }

}
